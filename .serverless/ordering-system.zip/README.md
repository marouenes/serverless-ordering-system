# serverless-ordering-system
Amazon Web Services for Developers: Data-Driven Serverless Applications with Kinesis
